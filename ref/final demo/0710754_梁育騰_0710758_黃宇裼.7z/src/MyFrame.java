import java.util.ArrayList;

import javafx.scene.control.Button;
import javafx.event.*;
import javafx.geometry.Point2D;

public class MyFrame {
    private double angle;
    private ArrayList<MyFramePoint> myFramePoints;
    
    private class MyFramePoint {
        // Button 
    }
}
